﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class new_borrowing_operation : System.Web.UI.Page
{
    int book_id;
    int borrower_id;
    string b_date;
    string r_date;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        book_id = int.Parse(TextBox1.Text);
        borrower_id = int.Parse(TextBox2.Text);
        b_date = TextBox3.Text;
        r_date = TextBox4.Text;

        SqlConnection con = new SqlConnection(@"Data Source=EMAD-ABDO;Initial Catalog=library;Integrated Security=True;");
        SqlCommand command = new SqlCommand();
        command.Connection = con;
       
           
        command.CommandText = string.Format("insert into Borrowing1_table Values('{0}','{1}','{2}','{3}') ",book_id, borrower_id, b_date,r_date);


        con.Open();

        string output = command.ExecuteNonQuery().ToString();
        if (output == "1")
        {
            Label1.Visible = true;
            Label1.Text = "Success";
        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "Failed";
        }

        con.Close();

        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        
        
        }

    }
