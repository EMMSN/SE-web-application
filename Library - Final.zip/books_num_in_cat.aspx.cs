﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class books_num_in_cat : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
           
        }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=EMAD-ABDO;Initial Catalog=library;Integrated Security=True;");
        string query = "select count(*) from Book1_table where Category ='" + DropDownList1.SelectedItem.Value + "'";
        SqlCommand cmd = new SqlCommand(query, con);
        con.Open();

        SqlDataReader DR1 = cmd.ExecuteReader();
        if (DR1.Read())
        {
            TextBox1.Text = DR1.GetValue(0).ToString();
        }
        con.Close();
    }
}

    
  


