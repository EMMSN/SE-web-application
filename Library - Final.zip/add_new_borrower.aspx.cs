﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class add_new_borrower : System.Web.UI.Page
{
    string Fname;
    string Midname;
    string Lname;
    string Address;
    string Email;
    string Dept;
    int phone_numb;

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

   
    protected void Button1_Click1(object sender, EventArgs e)
    {
           Fname = TextBox2.Text;
            Midname = TextBox3.Text;
            Lname = TextBox4.Text;
            phone_numb = int.Parse(TextBox5.Text);
            Dept = DropDownList1.SelectedItem.Value;
            Email = TextBox6.Text;
            Address = TextBox7.Text;


        SqlConnection con = new SqlConnection(@"Data Source=EMAD-ABDO;Initial Catalog=library;Integrated Security=True;");
        SqlCommand command = new SqlCommand();
        command.Connection = con;
       
           
        command.CommandText = string.Format("insert into Borrower_table Values('{0}','{1}','{2}','{3}','{4}','{5}','{6}') ",Fname, Midname, Lname,phone_numb,Dept,Email,Address);


        con.Open();

        string output = command.ExecuteNonQuery().ToString();
        if (output == "1")
        {
            Label1.Visible = true;
            Label1.Text = "Success";
        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "Failed";
        }

        con.Close();

        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        
        }
    }

