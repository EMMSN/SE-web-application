﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class search_by_author : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
      
            
     
    }

    protected void Buttonsearch_Click(object sender, EventArgs e)
    {

        SqlConnection conn = new SqlConnection(@"Data Source=EMAD-ABDO;Initial Catalog=library;Integrated Security=True;");
        SqlCommand command = new SqlCommand();
        command.Connection = conn;

        command.CommandText = string.Format("select * from Book1_table where Author_name= {0}", Stextbox.Text);

        conn.Open();

        SqlDataReader dr = command.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                string id = dr[0].ToString();
                string name = dr[1].ToString();
                string AUTHOR = dr[2].ToString();
                string year = dr[3].ToString();


                Response.Write(GridView1);



            }
        }
        else
        {

        }


        conn.Close();

        Stextbox.Text = "";
    }



}

