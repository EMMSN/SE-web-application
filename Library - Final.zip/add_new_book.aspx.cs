﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class add_new_book : System.Web.UI.Page
{
    
    string Book_name;
    string Author_name;
    string Year_published;
    string Status;
    string Category;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
           
        }
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {

        Book_name = TextBox2.Text;
        Author_name = TextBox3.Text;
        Year_published = TextBox4.Text;
        Status = DropDownList2.SelectedItem.Value;
        Category = DropDownList1.SelectedItem.Value;
        SqlConnection con = new SqlConnection(@"Data Source=EMAD-ABDO;Initial Catalog=library;Integrated Security=True;");
        // cmd.Connection = con;
        SqlCommand command = new SqlCommand();
        command.Connection = con;
        command.CommandText = string.Format("insert into Book1_table Values('{0}','{1}','{2}','{3}','{4}') ", Book_name, Author_name, Year_published, Status, Category);


        con.Open();

        string output = command.ExecuteNonQuery().ToString();
        if (output == "1")
        {
            Label1.Visible = true;
            Label1.Text = "Success";
        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "Failed";
        }

        con.Close();
       
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";


    }
}
