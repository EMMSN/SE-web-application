﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class update_book : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=EMAD-ABDO;Initial Catalog=library;Integrated Security=True;");

        con.Open();
        string query = " update Book1_table set Status='" + DropDownList1.SelectedItem.Value + "' where Book_name = '" + TextBox1.Text + "'";

        SqlCommand cmd = new SqlCommand(query, con);
        cmd.ExecuteScalar();
        con.Close();
        TextBox1.Text = "";
    
    }
}