﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class number_of_borrowers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=EMAD-ABDO;Initial Catalog=library;Integrated Security=True;");
        string query = " select count(*) from Borrower_table";
        SqlCommand cmd = new SqlCommand(query, con);
        con.Open();
        SqlDataReader DR1 = cmd.ExecuteReader();
        if (DR1.Read())
        {
            TextBox1.Text = DR1.GetValue(0).ToString();
        }
        con.Close();
    }
}