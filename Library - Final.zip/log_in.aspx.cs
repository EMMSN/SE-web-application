﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class log_in : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void LogInBtn_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(@"Data Source=EMAD-ABDO;Initial Catalog=library;Integrated Security=True;"); 

        con.Open();
        string query = " select count(*) from Log_in where User_name = '" + TextBox1.Text + "' and Password = '" + TextBox2.Text + "'";

        SqlCommand cmd = new SqlCommand(query, con);
        string output = cmd.ExecuteScalar().ToString();
         
        if (output == "1")
        {
            Response.Redirect("Lib_functions.html");
        }
        else
        {
            Response.Write("<script>alert('Login Failed Please insert a vaild User name and Password')</script>");
        }
        con.Close();

    }
}
